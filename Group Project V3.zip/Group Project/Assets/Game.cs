﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Game : MonoBehaviour
{
    public static Game game;

    public List<CardTemplate> cards = new List<CardTemplate>();
    public int currentCard;
    private int oldCard = -1;

    //the following public gameobject implemented for test purposes
    public HUDUpdater hudUpdater;

    public Transform[] cardTemplatesParent;

    public GameObject cardTemplatePrefab;
    public Card testCard;

    private List<List<Vector2>> cardTemplatePositions = new List<List<Vector2>>()
    {
        new List<Vector2>() { new Vector2(0, 0), new Vector2(0, 0), new Vector2(0, 0), new Vector2(0, 0), new Vector2(0, 0) },
        new List<Vector2>() { new Vector2(-400, 0), new Vector2(400, 0), new Vector2(0, 0), new Vector2(0, 0), new Vector2(0, 0) },
        new List<Vector2>() { new Vector2(-800, 0), new Vector2(0, 0), new Vector2(800, 0), new Vector2(0, 0), new Vector2(0, 0) },
        new List<Vector2>() { new Vector2(-1200, 0), new Vector2(-400, 0), new Vector2(400, 0), new Vector2(1200, 0), new Vector2(0, 0)},
        new List<Vector2>() { new Vector2(-1600, 0), new Vector2(-800, 0), new Vector2(0, 0), new Vector2(800, 0), new Vector2(1600, 0) }
    };

    private void Awake()
    {
        game = this;

        PopulateCards(0);
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (cards.Count < 5)
            {
                PopulateCards(1);
            }
        }
        if (Input.GetKeyDown(KeyCode.F))
        {
            DeleteCard(currentCard);
        }

        //following section added for temporary ui tests
        if (Input.GetKeyDown(KeyCode.K))
        {
            hudUpdater.updateMoney(1);
        }
        if (Input.GetKeyDown(KeyCode.L))
        {
            hudUpdater.updateMoney(-1);
        }
        if (Input.GetKeyDown(KeyCode.I))
        {
            hudUpdater.updateGrades(1);
        }
        if (Input.GetKeyDown(KeyCode.O))
        {
            hudUpdater.updateGrades(-1);
        }
        if (Input.GetKeyDown(KeyCode.N))
        {
            hudUpdater.updateSocial(1);
        }
        if (Input.GetKeyDown(KeyCode.M))
        {
            hudUpdater.updateSocial(-1);
        }
        //and so ends the test section

        if (cards.Count != 0)
        {
            if (oldCard != currentCard)
            {
                if (oldCard != -1)
                {
                    cards[oldCard].GetComponent<Animator>().SetTrigger("Deselect");
                }
                cards[currentCard].GetComponent<Animator>().SetTrigger("Select");

                oldCard = currentCard;
            }

            if (Input.GetKeyDown(KeyCode.A))
            {
                currentCard--;
                currentCard = Mathf.Clamp(currentCard, 0, cards.Count - 1);
            }
            if (Input.GetKeyDown(KeyCode.D))
            {
                currentCard++;
                currentCard = Mathf.Clamp(currentCard, 0, cards.Count - 1);
            }
        }

        for(int i = 0; i < 5; i++)
        {
            if (cards.Count == 0)
                break;

            cardTemplatesParent[i].localPosition = cardTemplatePositions[cards.Count - 1][i];
        }
    }

    private void PopulateCards (int amount)
    {
        for (int i = 0; i < amount; i++)
        {
            GameObject g = Instantiate(cardTemplatePrefab);
            g.transform.SetParent(cardTemplatesParent[cards.Count + i], false);

            CardTemplate c = g.GetComponent<CardTemplate>();
            c.card = testCard;

            cards.Add(c);
        }
    }

    private void DeleteCard (int slot)
    {
        Transform p = cardTemplatesParent[slot];

        if (p.childCount == 0)
            return;

        Destroy(p.GetChild(0).gameObject);

        cards.Remove(cards[slot]);

        oldCard = -1;
        currentCard = 0;

        ReorganizeCards();
    }

    private void ReorganizeCards ()
    {
        for (int i = 0; i < cards.Count; i++)
        {
            cards[i].transform.SetParent(cardTemplatesParent[i], false);
        }
    }
}
