﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class TimerStuff : MonoBehaviour
{
    //Control of variables in unity editor
    [SerializeField] private Text uiText;
    [SerializeField] private float mainTimer;

    //Stores int of scene to change
    private int nextSceneIndex;
    
    //Variables for timer
    private float timer;
    private bool counter = true;
    private bool timing = false;

    //Sets timer to variable stated in editor
    private void Start()
    {
        timer = mainTimer;
    }

    //Timer updates every update
    private void Update()
    {
        if(timer >= 0f && counter)
        {
            timer -= Time.deltaTime;
            uiText.text = timer.ToString("F");
        }

        //If timer gets to 0, stop timer and call NextScene
        else if(timer <= 0f && !timing)
        {
            counter = false;
            timing = true;
            uiText.text = "0";
            timer = 0f;
            NextScene();
        }
    }

    //Goes to next scene
    void NextScene()
    {
        nextSceneIndex = SceneManager.GetActiveScene().buildIndex + 1;
        
        SceneManager.LoadScene(nextSceneIndex);
    }
}
