﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HUDUpdater : MonoBehaviour
{

    public Text moneyText;
    int money;
    public Slider gradesBar;
    int grades;
    public Slider socialBar;
    int social;

    void Start()
    {
        money = PlayerPrefs.GetInt("currentMoney");
        moneyText.text = money.ToString();
    }

    public void updateMoney(int change)
    {
        money += change;
        moneyText.text = money.ToString();
        PlayerPrefs.SetInt("currentMoney",money);
    }
    public void updateGrades(int change)
    {
        grades += change;
        gradesBar.value = grades;
    }
    public void updateSocial(int change)
    {
        social += change;
        socialBar.value = social;
    }
}
