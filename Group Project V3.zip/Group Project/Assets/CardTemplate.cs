﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CardTemplate : MonoBehaviour
{
    public Card card;

    private Image color;
    private Text title;
    private Text description;

    private void Start()
    {
        color = transform.Find("Border").GetComponent<Image>();
        title = transform.Find("Title").GetComponent<Text>();
        description = transform.Find("Description").GetComponent<Text>();

        UpdateGraphics();
    }

    private void UpdateGraphics ()
    {
        color.color = card.color;
        title.text = card.name;
        description.text = card.description;
    }
}
