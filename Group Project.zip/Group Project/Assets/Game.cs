﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Game : MonoBehaviour
{
    public static Game game;

    public int currentCard;
    private int oldCard = -1;

    public int handSize;

    [Header("Starting Decks")]
    public Deck startingDeck;
    public CardTemplate startingVisuals;

    [Header("Hand")]
    public Deck hand;
    public List<CardTemplate> handVisuals = new List<CardTemplate>();

    [Header("Discard")]
    public Deck discard;
    public CardTemplate discardVisuals;

    [Header("Trash")]
    public Deck trash;
    public CardTemplate trashVisuals;

    [Header("Positions")]
    public Vector2 handOffset;
    public Vector2 deckOffset;

    public Transform[] cardTemplatesParent;

    public GameObject cardTemplatePrefab;
    public Card[] testCards;

    public List<int> selectedCards = new List<int>();

    private List<List<Vector2>> cardTemplatePositions = new List<List<Vector2>>()
    {
        new List<Vector2>() { new Vector2(0, 0), new Vector2(0, 0), new Vector2(0, 0), new Vector2(0, 0), new Vector2(0, 0) },
        new List<Vector2>() { new Vector2(-400, 0), new Vector2(400, 0), new Vector2(0, 0), new Vector2(0, 0), new Vector2(0, 0) },
        new List<Vector2>() { new Vector2(-800, 0), new Vector2(0, 0), new Vector2(800, 0), new Vector2(0, 0), new Vector2(0, 0) },
        new List<Vector2>() { new Vector2(-1200, 0), new Vector2(-400, 0), new Vector2(400, 0), new Vector2(1200, 0), new Vector2(0, 0)},
        new List<Vector2>() { new Vector2(-1600, 0), new Vector2(-800, 0), new Vector2(0, 0), new Vector2(800, 0), new Vector2(1600, 0) }
    };

    private void Awake()
    {
        game = this;
    }
    private void Start()
    {
        startingDeck.ShuffleDeck();
    }
    private void Update()
    {
        InputHandler();

        // handlers that handle different decks on the screen
        HandHandler();
        CardVisualsHandler();

        if (startingDeck.Count == 0 && hand.Count == 0)
        {
            if (Input.GetKeyDown(KeyCode.Q))
            {
                // next turn lmao
                TransferDeck(discard, startingDeck);
            }
        }
    }

    private void HandHandler ()
    {
        if (hand.Count != 0)
        {
            if (Input.GetKeyDown(KeyCode.A))
            {
                currentCard--;
                if (currentCard < 0)
                {
                    currentCard = hand.Count - 1;
                }
            }
            if (Input.GetKeyDown(KeyCode.D))
            {
                currentCard++;
                if (currentCard > hand.Count - 1)
                {
                    currentCard = 0;
                }
            }
        }
        else
        {
            while (startingDeck.Count > 0 && hand.Count < handSize)
            {
                TransferCard(startingDeck, hand, 0);
            }
        }

        for (int i = 0; i < handSize; i++)
        {
            if (i < hand.Count)
            {
                handVisuals[i].gameObject.SetActive(true);
                handVisuals[i].card = hand.cards[i];
            }
            else
            {
                handVisuals[i].gameObject.SetActive(false);
            }

            if (hand.Count != 0)
            {
                cardTemplatesParent[i].localPosition = cardTemplatePositions[hand.Count - 1][i] + (selectedCards.Contains(i) ? new Vector2(0F, 100F) : Vector2.zero) + handOffset;
            }
        }
    }
    private void CardVisualsHandler ()
    {
        discardVisuals.gameObject.SetActive(discard.Count != 0);
        discardVisuals.card = discard.topCard;

        startingVisuals.gameObject.SetActive(startingDeck.Count != 0);
        startingVisuals.card = startingDeck.topCard;

        trashVisuals.gameObject.SetActive(trash.Count != 0);
        trashVisuals.card = trash.topCard;
    }

    /// <summary>
    /// A function to handle input.
    /// </summary>
    private void InputHandler ()
    {
        if (Input.GetKeyDown(KeyCode.F))
        {
            if (hand.Count != 0)
            {
                TransferCard(hand, discard, currentCard);

                oldCard = -1;
                currentCard = 0;

                // set the old card and current card to avoid animation problems
                OrganizeHand();
            }
        }

        if (Input.GetKeyDown(KeyCode.G))
        {
            handVisuals[currentCard].FlipCard();
        }

        if (Input.GetKeyDown(KeyCode.Return))
        {
            if (selectedCards.Contains(currentCard))
            {
                selectedCards.Remove(currentCard);
            }
            else
            {
                selectedCards.Add(currentCard);
            }
        }
    }

    /// <summary>
    /// Transfers a card from one deck to another.
    /// </summary>
    /// <param name="slot">The slot that the card is being removed from.</param>
    private void TransferCard (Deck from, Deck to, int slot)
    {
        // adds this card to the to pile
        to.AddCard(from.cards[slot]);

        // remove the card from the from pile.
        from.RemoveCard(slot);
    }
    
    /// <summary>
    /// Transfers all cards from one deck to another.
    /// </summary>
    /// <param name="from"></param>
    /// <param name="to"></param>
    private void TransferDeck (Deck from, Deck to)
    {
        while(from.Count != 0)
        {
            TransferCard(from, to, 0);
        }
    }

    /// <summary>
    /// Realigns the hand objects when a card is added or removed.
    /// </summary>
    private void OrganizeHand ()
    {
        for (int i = 0; i < hand.Count; i++)
        {
            handVisuals[i].transform.SetParent(cardTemplatesParent[i], false);
        }
    }
}

[System.Serializable]
public class Deck
{
    // a stored list of cards
    public List<Card> cards = new List<Card>();

    // the amount of cards in this deck
    public int Count
    {
        get
        {
            return cards.Count;
        }
    }

    // returns the top card in the deck
    public Card topCard
    {
        get
        {
            if (cards.Count == 0)
                return null;
            return cards[Count-1];
        }
    }

    /// <summary>
    /// Adds a card to the deck.
    /// </summary>
    /// <param name="card">The card you want to add.</param>
    public void AddCard (Card card)
    {
        cards.Add(card);
    }

    /// <summary>
    /// Removes a card from the deck at the given index.
    /// </summary>
    /// <param name="index">The position of the card you want to remove.</param>
    public void RemoveCard (int index)
    {
        if (index < cards.Count)
        {
            cards.Remove(cards[index]);
        }
    }
    /// <summary>
    /// Removes a card from the deck.
    /// </summary>
    /// <param name="card">The card you want to remove.</param>
    public void RemoveCard (Card card)
    {
        if (cards.Contains(card))
        {
            cards.Remove(card);
        }
    }

    /// <summary>
    /// Shuffles the deck.
    /// </summary>
    public void ShuffleDeck ()
    {
        List<Card> newlist = new List<Card>();

        while (cards.Count > 0)
        {
            int r = Random.Range(0, cards.Count);

            newlist.Add(cards[r]);
            cards.Remove(cards[r]);
        }

        cards = newlist;
    }
}